from collections import deque

def format_sequence(converters_info, source_format, destination_format):

    """
        KEY NOTES:
            Finds the SHORTEST sequence of format conversions to get from source → destination.
            Uses BFS because every conversion step costs the same (1 step) — no weights needed.
            Returns a list of vertex (format) numbers, or None if destination is unreachable.

            Step 1: Base Case
                Are source and destination the same? Return [source] immediately.
                    e.g. format_sequence("D 2\\n0 1\\n", 1, 1) → [1]

            Step 2: Initialise
                visited[]  → prevents re-visiting formats we've already checked
                parent[]   → stores which format we came FROM to reach each format
                              This lets us RECONSTRUCT the path at the end without storing
                              full paths in the queue (more memory efficient than storing lists)
                queue      → BFS queue, starts with just the source format

            Step 3: BFS
                Pop from FRONT of queue (FIFO = nearest formats explored first = shortest path)
                For each neighbour: if unvisited, record parent and enqueue
                Stop as soon as we reach destination_format

            Step 4: Reconstruct
                Walk backwards through parent[] from destination → source
                Then reverse the result to get source → destination order
    """

    n, adj, _, _ = read_graph(converters_info)
    # Unpack: n = number of formats, adj = adjacency list of available conversions
    # Discard directed/weighted flags — we just need adjacency here

    print(f"Graph has {n} formats (vertices)")
    print(f"Adjacency list: {adj}")
    print(f"Converting from format {source_format} → {destination_format}\n")

    # ── Step 1: Base Case ─────────────────────────────────────────────────────
    if source_format == destination_format:
        print("Already at destination! No conversion needed.")
        return [source_format]
        # e.g. mp3 → mp3: already done, return as-is

    # ── Step 2: Initialise ────────────────────────────────────────────────────
    visited = [False] * n   # visited[i] = True once format i has been seen
    parent  = [-1]    * n   # parent[i]  = which format we came from to reach i
                            # source's parent stays -1 (we never set it = loop terminator)

    queue = deque()
    queue.append(source_format)
    visited[source_format] = True   # Mark source immediately — don't re-add it
    # Why mark before processing? Prevents the source being added to queue again
    # if a neighbour also has it as a neighbour

    found = False   # Flips to True the moment we locate destination_format

    # ── Step 3: BFS ───────────────────────────────────────────────────────────
    while queue:
        current = queue.popleft()   # Take from FRONT (FIFO) → explores nearest formats first
        print(f"Checking format {current}, queue: {list(queue)}")

        for neighbour in adj[current]:  # Go through all formats reachable from current

            if not visited[neighbour]:
                visited[neighbour] = True
                parent[neighbour] = current     # "We reached neighbour by coming from current"
                print(f"    Format {neighbour} reachable from {current}, recording parent")

                if neighbour == destination_format:
                    found = True
                    print(f"    Destination {destination_format} found!")
                    break   # Stop immediately — BFS guarantees this is the shortest path

                queue.append(neighbour)     # Add to back of queue for later exploration

        if found:
            break   # Break out of outer while loop too

    # ── No path found ─────────────────────────────────────────────────────────
    if not found:
        print(f"No conversion path from {source_format} to {destination_format}")
        return None     # Destination is unreachable from source

    # ── Step 4: Reconstruct path ──────────────────────────────────────────────
    # Walk backwards from destination → source using parent pointers
    # Example: source=1, destination=4, parent=[..., -1, 2, 1, ..., 2, ...]
    #          4 → parent[4]=2 → parent[2]=1 → parent[1]=-1 (stop)
    #          path built backwards: [4, 2, 1] → reversed: [1, 2, 4]

    path = []
    node = destination_format
    while node != -1:   # -1 is the sentinel for "this is the source, stop here"
        path.append(node)
        node = parent[node]

    path.reverse()  # Built destination→source, flip to source→destination
    print(f"Path reconstructed: {path}")
    return path
    # Returns e.g. [1, 0, 2] meaning: convert 1→0 then 0→2
