package seng201.tut2.gui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import seng201.tut2.RocketManager;

import java.io.IOException;

/**
 * Class that handles navigation between various {@link ScreenController}s. This navigator
 * uses a {@link BorderPane} layout for the root pane. A launched screen is placed in the
 * center area of the border pane, replacing the previous screen if any.
 *
 * @author seng201 teaching team
 */
public class ScreenNavigator {

    private final Stage stage;

    private final BorderPane rootPane;

    /**
     * Creates a ScreenNavigator with the given stage.
     *
     * @param stage The JavaFX stage
     */
    public ScreenNavigator(Stage stage) {
        this.stage = stage;

        // Create a layour with a top bottom left right and center. this acts as Our central hub from where we actually switch the scenes
        rootPane = new BorderPane();
        rootPane.setPrefHeight(400);
        rootPane.setPrefWidth(600);
        stage.setScene(new Scene(rootPane));
        stage.show();
    }

    public void GoToMain() {
        loadScreen("./fxml/main_screen.fxml");
    }

    private void loadScreen(String s) {
    }

    /**
     * Creates the new controller ScreenController that allows us to swap between the different screens
     * This is then parsed to the launch method
     *
     * @param rocketManager The rocket manager used by the setup screen controller
     */
    public void launchSetupScreen(RocketManager rocketManager) {
        ScreenController controller = new SetupScreenController(rocketManager);
        launchScreen(controller);
    }

    /**
     * Launches the main screen.
     *
     * @param rocketManager The rocket manager used by the main screen controller
     */
    public void launchMainScreen(RocketManager rocketManager) {
        ScreenController controller = new MainScreenController(rocketManager);
        launchScreen(controller);
    }

    /**
     * Replaces the root border pane's center component with the screen defined by the given
     * {@link ScreenController}.
     *
     * @param controller The JavaFX screen controller for the screen to be launched
     */
    private void launchScreen(ScreenController controller) {
        try {
            // this where the magic happens
            // This is just used to locate the actual fxml file
            FXMLLoader setupLoader = new FXMLLoader(getClass().getResource(controller.getFxmlFile()));

            // Set a controller that returns the given ScreenController.
            // This allows us to have screen controllers that take argument(s) in their constructor.
            // We need this for when we have multiple contructors on each of our different fxml's
            setupLoader.setControllerFactory(param -> controller);
            Parent setupParent  = setupLoader.load();
            // This physically removes the old screen and set's this as the new one
            rootPane.setCenter(setupParent);
            stage.setTitle(controller.getTitle());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
