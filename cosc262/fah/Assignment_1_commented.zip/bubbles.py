from collections import deque

def bubbles(physical_contact_info):

    """
        KEY NOTES:
            This function finds all connected components (bubbles) in an undirected graph.
            Each person who can reach each other (directly or indirectly) is in the same bubble.
            Uses BFS from every unvisited vertex.

            Step 1: Base Case
                Is the graph empty (n == 0)? If so return [] — no people, no bubbles.

            Step 2: Initialise
                visited[]   → tracks which people are already in a bubble (prevents double counting)
                result      → the list of all discovered bubbles

            Step 3: Outer Loop - try every person as a potential bubble starting point
                If they're already visited: skip — they're in a bubble from an earlier BFS.

            Step 4: Inner BFS
                Flood-fill outward from the starting person through all their contacts.
                Everyone reachable in this pass = same bubble.
                    e.g. 0 contacts 1, 1 contacts 3 → 0, 1, 3 all in the same bubble

            Step 5: Append the completed bubble to result and repeat.
    """

    n, adj, _, _ = read_graph(physical_contact_info)
    # Unpack: n = number of people, adj = adjacency list
    # We discard directed/weighted flags (this is always undirected for bubbles)

    print(f"Graph has {n} people (vertices)")
    print(f"Adjacency list: {adj}\n")

    if n == 0:
        print("Empty graph — no people, no bubbles!")
        return []   # Edge case: no vertices at all

    visited = [False] * n   # visited[i] = True once person i is assigned to a bubble
    result = []             # Will hold a list of lists — one list per bubble

    for start in range(n):  # Try every person as a possible new-bubble starting point

        if visited[start]:
            print(f"  Person {start} already in a bubble, skipping!")
            continue    # Already in a bubble found earlier — skip

        # ── New bubble discovered! BFS to find all members ───────────────
        print(f"Starting new bubble from person {start}")

        bubble = []     # Accumulate all members of this bubble
        queue = deque()
        queue.append(start)
        visited[start] = True   # Mark as visited NOW to avoid adding to queue twice
        # Why mark before processing? So if two already-queued people share a contact,
        # we don't add that contact to the queue twice

        while queue:
            current = queue.popleft()   # Take from FRONT of queue (FIFO = BFS order)
            bubble.append(current)      # This person is confirmed in the bubble
            print(f"    Visiting person {current}, bubble so far: {bubble}")

            for neighbour in adj[current]:  # Spread to all direct contacts
                if not visited[neighbour]:
                    visited[neighbour] = True
                    queue.append(neighbour) # BFS ensures everyone reachable is included
                    print(f"        Queueing person {neighbour} (contact of {current})")

        print(f"  Bubble complete: {bubble}\n")
        result.append(bubble)   # One bubble fully discovered — save and move on

    print(f"All bubbles: {result}")
    return result
    # Returns e.g. [[0], [1, 2, 3, 4, 5, 6]]
    # List of lists — each inner list is one connected bubble of people
