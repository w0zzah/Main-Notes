import heapq

def adjacency_list(graph_str):

    lines = graph_str.strip().split('\n')
    header = lines[0].split()
    direction   = header[0]
    is_directed = (direction == 'D')
    is_weighted = (len(header) == 3 and header[2] == 'W')
    n = int(header[1])

    adj = [[] for _ in range(n)]

    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        u = int(parts[0])
        v = int(parts[1])

        if is_weighted:
            w = int(parts[2])
            adj[u].append((v, w))
            if not is_directed:
                adj[v].append((u, w))
        else:
            adj[u].append(v)
            if not is_directed:
                adj[v].append(u)

    return n, adj


def min_capacity(city_map, depot_position):

    """
        KEY NOTES:
            Find the MINIMUM battery capacity so a vehicle can make a round trip
            from the depot to ANY location and return with ≥25% charge remaining.

            Battery math (worked out once here so we don't redo it in the code):
                Travel rate:          2 units distance per 3 units battery
                Battery per distance: 3/2 units battery per unit distance
                Round trip distance:  2 × shortest_path_distance
                Battery used:         (3/2) × 2 × d  =  3d

                Must have 25% left →  used ≤ 75% of capacity:
                    3d ≤ 0.75 × capacity
                    capacity ≥ 3d / 0.75
                    capacity ≥ 4d          ← clean integer, no fractions needed!

            So: required_capacity = 4 × max_shortest_path_distance (pure integer!)

            Algorithm: Dijkstra's from depot_position to find shortest paths to all vertices.
            Then return 4 × the MAXIMUM of those shortest paths.

            Step 1: Initialise distances to ∞, depot to 0, push depot onto min-heap.
            Step 2: Dijkstra — always process the currently closest unvisited vertex.
            Step 3: Find maximum shortest path (worst-case round trip destination).
            Step 4: Return 4 × max distance (the minimum capacity that covers all trips).
    """

    n, adj = adjacency_list(city_map)
    print(f"Graph has {n} locations")
    print(f"Depot is at position {depot_position}")
    print(f"Adjacency list: {adj}\n")

    # ── Step 1: Initialise ────────────────────────────────────────────────────
    dist = [float('inf')] * n
    # dist[i] = shortest known distance from depot_position to vertex i
    # Start with infinity = "not yet reached"

    dist[depot_position] = 0    # Distance from depot to itself is 0
    print(f"Step 1: Initial distances: {dist}")

    heap = [(0, depot_position)]
    # Min-heap: entries are (distance_so_far, vertex)
    # heapq always pops the smallest distance first — this is what makes it Dijkstra's

    # ── Step 2: Dijkstra ──────────────────────────────────────────────────────
    print("\nStep 2: Running Dijkstra...")
    while heap:
        d, u = heapq.heappop(heap)
        # d = distance we used to reach u; u = current vertex

        if d > dist[u]:
            continue
            # This is a STALE heap entry — we already found a shorter path to u earlier.
            # Dijkstra can leave outdated entries in the heap; this check skips them.
            # Example: we push (5, 2) then find (3, 2) later — when we pop the old (5, 2),
            #          dist[2] is already 3, so 5 > 3 → skip it.

        print(f"  Processing vertex {u} at distance {d}")

        for (v, w) in adj[u]:  # Look at all neighbours of u
            new_dist = dist[u] + w      # Tentative distance to v via u

            if new_dist < dist[v]:      # Is this a shorter path to v?
                dist[v] = new_dist      # Yes! Update shortest known distance to v
                heapq.heappush(heap, (new_dist, v))
                # Add to heap so we explore v's neighbours with this improved distance
                print(f"    Updated dist[{v}] = {new_dist}  (via vertex {u})")

    print(f"\nFinal shortest distances from depot {depot_position}: {dist}")

    # ── Step 3: Find maximum shortest path ───────────────────────────────────
    # We need capacity to handle the WORST CASE = the farthest reachable location
    max_dist = 0
    for i in range(n):
        if dist[i] != float('inf'):             # Only consider reachable locations
            if dist[i] > max_dist:
                max_dist = dist[i]
                print(f"Step 3: New max distance = {max_dist}  (vertex {i})")
    # dist[i] == inf means vertex i is unreachable — problem guarantees connectivity,
    # but we guard against it anyway

    # ── Step 4: Calculate minimum capacity ───────────────────────────────────
    capacity = 4 * max_dist
    # Derivation recap:
    #   battery_used = (3/2) × round_trip = (3/2) × 2 × max_dist = 3 × max_dist
    #   25% must remain → used ≤ 75% → 3 × max_dist ≤ 0.75 × capacity
    #   → capacity ≥ 4 × max_dist   ✓  (clean integer multiplication, no floats!)

    print(f"\nStep 4: max_dist = {max_dist}, minimum capacity = 4 × {max_dist} = {capacity}")
    return capacity


# ── Test Cases ────────────────────────────────────────────────────────────────

city_map = """\
U 4 W
0 2 5
0 3 2
3 2 1
"""

print(min_capacity(city_map, 0))   # Expected: 12  (farthest reachable = 3, capacity = 4×3)
print(min_capacity(city_map, 1))   # Expected: 0   (vertex 1 is isolated → only dest = itself)
print(min_capacity(city_map, 2))   # Expected: 12
print(min_capacity(city_map, 3))   # Expected: 12
